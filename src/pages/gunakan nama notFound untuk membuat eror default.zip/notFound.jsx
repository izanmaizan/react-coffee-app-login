const NotFound = () => {
	return <h1>Tidak Ditemukan</h1>
}

export default 	NotFound